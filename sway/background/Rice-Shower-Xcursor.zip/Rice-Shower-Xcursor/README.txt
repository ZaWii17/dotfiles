Rice Shower Xcursor theme
Converted from the supplied Rice Shower Hyprcursor pack.

Install: copy this folder to ~/.local/share/icons/ and select 'Rice-Shower' in your desktop cursor theme settings.
For X11: set XCURSOR_THEME=Rice-Shower. For Wayland compositors, select it in your compositor's cursor theme settings.
